import React, { useState } from 'react';

function ReportPage() {
    return (
      <div className="App" style={{ marginTop: '20px'}}>
        
        <iframe src="https://datastudio.google.com/embed/reporting/8677c2bb-a36e-4cda-870d-a01d73766b3f/page/Cct8C" width={1000} height={500} frameborder="0" allowfullscreen></iframe>

      </div>
    );
  }

export default ReportPage;
